Guggu Malkin Land - static website
Files: index.html, lands.html, barhaj-plot.html, lucknow.html, gkp.html, deoria.html, contact.html
Images included. To go live: upload to GitHub Pages (see instructions).